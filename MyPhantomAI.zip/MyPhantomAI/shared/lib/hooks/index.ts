// Export shared hooks that work across web and mobile
export * from './useAuth.js';
export * from './useMobile.js';
