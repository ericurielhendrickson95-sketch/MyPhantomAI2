import { useAuthContext } from '../context/index.js';

export function useAuth() {
  return useAuthContext();
}
