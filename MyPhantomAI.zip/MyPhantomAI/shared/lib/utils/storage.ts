// Cross-platform storage utilities
export async function getItem(key: string): Promise<string | null> {
  // Implementation handled by platform-specific code
  throw new Error('getItem not implemented in shared library');
}

export async function setItem(key: string, value: string): Promise<void> {
  // Implementation handled by platform-specific code
  throw new Error('setItem not implemented in shared library');
}

export async function removeItem(key: string): Promise<void> {
  // Implementation handled by platform-specific code
  throw new Error('removeItem not implemented in shared library');
}
