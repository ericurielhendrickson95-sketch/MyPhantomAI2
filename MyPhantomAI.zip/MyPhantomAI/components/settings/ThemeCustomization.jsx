import React, { useState, useEffect } from 'react';
import { Palette, Check, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const THEMES = [
  { id: 'cyan',   label: 'Phantom Blue',  primary: '200 80% 70%', accent: '270 60% 65%', preview: '#64c8ff' },
  { id: 'violet', label: 'Violet Surge',  primary: '270 80% 72%', accent: '200 60% 65%', preview: '#a855f7' },
  { id: 'emerald',label: 'Matrix Green', primary: '150 70% 55%', accent: '180 60% 50%', preview: '#34d399' },
  { id: 'rose',   label: 'Crimson Ghost', primary: '340 80% 65%', accent: '20 70% 60%',  preview: '#f43f5e' },
  { id: 'amber',  label: 'Solar Flare',   primary: '38 90% 60%',  accent: '20 80% 55%',  preview: '#f59e0b' },
  { id: 'teal',   label: 'Deep Ocean',    primary: '180 75% 55%', accent: '220 60% 65%', preview: '#14b8a6' },
];

function applyTheme(theme) {
  const root = document.documentElement;
  root.style.setProperty('--primary', theme.primary);
  root.style.setProperty('--ring', theme.primary);
  root.style.setProperty('--accent', theme.accent);
}

export default function ThemeCustomization() {
  const [selected, setSelected] = useState('cyan');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      const themeId = u?.theme || 'cyan';
      setSelected(themeId);
      const theme = THEMES.find((t) => t.id === themeId);
      if (theme) applyTheme(theme);
    }).catch(() => {});
  }, []);

  const handleSelect = async (theme) => {
    setSelected(theme.id);
    applyTheme(theme);
    setSaving(true);
    setSaved(false);
    await base44.auth.updateMe({ theme: theme.id });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  return (
    <div className="p-4 rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.12)] space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-primary" />
          <span className="text-sm font-body text-foreground">Theme Color</span>
        </div>
        {saving && <Loader2 className="w-3.5 h-3.5 text-muted-foreground animate-spin" />}
        {saved && <span className="text-[11px] text-emerald-400">Saved</span>}
      </div>

      <div className="grid grid-cols-3 gap-2">
        {THEMES.map((theme) => (
          <button
            key={theme.id}
            onClick={() => handleSelect(theme)}
            className={`relative flex flex-col items-center gap-1.5 p-2.5 rounded-lg border transition-all select-none ${
              selected === theme.id
                ? 'border-white/30 bg-white/5'
                : 'border-[rgba(100,200,255,0.1)] hover:border-[rgba(100,200,255,0.2)]'
            }`}
          >
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ backgroundColor: theme.preview + '33', border: `2px solid ${theme.preview}` }}
            >
              {selected === theme.id && <Check className="w-3.5 h-3.5" style={{ color: theme.preview }} />}
            </div>
            <span className="text-[10px] text-muted-foreground font-body text-center leading-tight">{theme.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}