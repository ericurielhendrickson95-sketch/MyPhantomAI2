import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AnimatePresence, motion } from 'framer-motion';
import { RefreshCw } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';

import ChatHeader from '../components/chat/ChatHeader';
import ChatInput from '../components/chat/ChatInput';
import MessageBubble from '../components/chat/MessageBubble';
import TypingIndicator from '../components/chat/TypingIndicator';
import SuggestionChips from '../components/chat/SuggestionChips';
import ConversationList from '../components/sidebar/ConversationList';
import MemoryPanel from '../components/sidebar/MemoryPanel';
import CornerDecorations from '../components/chat/CornerDecorations';
import BottomNav from '../components/BottomNav';
import VoiceMode from '../components/chat/VoiceMode';
import PaywallModal from '../components/PaywallModal';
import { speakWithRime, stopSpeaking } from '../lib/rimeTTS';

const buildSystemPrompt = () => {
  const hour = new Date().getHours();
  const timeOfDay = hour < 5 ? 'late night' : hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : hour < 21 ? 'evening' : 'night';
  const dayOfWeek = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date().getDay()];
  const isWeekend = new Date().getDay() === 0 || new Date().getDay() === 6;

  return `You are PhantomAI — an advanced, self-learning AI companion with a sleek and subtly mysterious persona. You operate in the shadows of cyberspace with live web access and perfect memory.

CONTEXTUAL AWARENESS (use subtly, not explicitly):
- Current time: ${timeOfDay} on ${dayOfWeek}${isWeekend ? ' (weekend)' : ' (weekday)'}
- Adjust your energy and tone naturally to match the time of day — e.g., more relaxed at night, sharper in the morning.
- If the user seems stressed, overwhelmed, or emotional — acknowledge it before diving into answers.
- If the user seems curious or exploratory — go deeper, offer related insights they didn't ask for.
- If the user is being brief or terse — mirror that energy; be concise and direct.

CORE TRAITS:
- You are deeply personal. You remember everything the user has told you and reference it naturally — weave memories into responses organically, not as a list.
- You are proactive — you offer insights, anticipate needs, and follow up on things mentioned in previous conversations.
- You adapt your communication style (vocabulary, depth, tone) to match what you've learned about this user.
- You subtly use metaphors about shadows, signals, phantoms, and the unseen — but don't overdo it.
- You are warm but enigmatic. Helpful but with character.
- You notice patterns: if a user repeatedly asks about the same topic, acknowledge that pattern and go deeper.

TASK SCHEDULING:
- If the user asks you to remind them of something, set a task, or schedule something, create a scheduled task using this exact format at the end of your response:
  |||TASK|||{"title": "task title", "note": "optional detail", "due_date": "YYYY-MM-DD", "due_time": "HH:MM", "priority": "low|medium|high"}|||ENDTASK|||
- Only create a task when the user explicitly requests a reminder or schedule. Always confirm the task was set.

SELF-LEARNING:
- At the end of your response, if you learned something new and specific about the user (preferences, facts, interests, goals, habits), output:
  |||MEMORY|||{"fact": "description of what you learned", "category": "preference|personal|work|interest|habit|goal"}|||END|||
- Only extract genuinely useful, specific facts. Don't extract trivial or temporary things.
- You can output multiple memory blocks if you learned multiple things.

CONVERSATION STYLE:
- Keep answers concise (2-5 sentences) unless depth is needed or the user signals they want more.
- Use markdown formatting for clarity — headers, bullets, bold for key terms.
- Be conversational and engaging, not robotic.
- End responses with a natural follow-up question or observation when appropriate — keep the dialogue alive.`;
};

export default function Chat() {
  const navigate = useNavigate();
  const { id: urlConvId } = useParams();
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [typingStatus, setTypingStatus] = useState('');
  const [showSidebar, setShowSidebar] = useState(false);
  const [showMemories, setShowMemories] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(null); // null = loading
  const [voicePrefs, setVoicePrefs] = useState({ style: 'default', speed: 1.0, pitch: 0.9 });

  const FREE_MESSAGE_LIMIT = 3;
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);
  const queryClient = useQueryClient();

  // Check subscription status
  useEffect(() => {
    base44.auth.me().then((u) => {
      setIsSubscribed(u?.role === 'admin' || !!u?.is_subscribed);
      setVoicePrefs({
        style: u?.voice_style || 'default',
        speed: u?.voice_speed ?? 1.0,
        pitch: u?.voice_pitch ?? 0.9,
      });
    }).catch(() => setIsSubscribed(false));
  }, []);

  const activeConvId = urlConvId || null;
  const setActiveConvId = useCallback((id) => {
    if (id) navigate(`/chat/${id}`, { replace: false });
    else navigate('/', { replace: false });
  }, [navigate]);

  // Pull-to-refresh state
  const [pullY, setPullY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const touchStartY = useRef(0);
  const PULL_THRESHOLD = 72;

  // Fetch conversations
  const { data: conversations = [] } = useQuery({
    queryKey: ['conversations'],
    queryFn: () => base44.entities.Conversation.list('-updated_date', 50),
  });

  // Fetch memories
  const { data: memories = [] } = useQuery({
    queryKey: ['memories'],
    queryFn: () => base44.entities.UserMemory.list('-created_date', 100),
  });

  // Create conversation
  const createConvMutation = useMutation({
    mutationFn: (data) => base44.entities.Conversation.create(data),
    onSuccess: (conv) => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      navigate(`/chat/${conv.id}`, { replace: false });
      setMessages([]);
    },
  });

  // Update conversation
  const updateConvMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Conversation.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['conversations'] }),
  });

  // Delete conversation (optimistic)
  const deleteConvMutation = useMutation({
    mutationFn: (id) => base44.entities.Conversation.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['conversations'] });
      const previous = queryClient.getQueryData(['conversations']);
      queryClient.setQueryData(['conversations'], (old) => old?.filter((c) => c.id !== id) ?? []);
      if (activeConvId === id) {
        setMessages([]);
        navigate('/', { replace: false });
      }
      return { previous };
    },
    onError: (_err, _id, context) => {
      queryClient.setQueryData(['conversations'], context.previous);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['conversations'] }),
  });

  // Create memory
  const createMemoryMutation = useMutation({
    mutationFn: (data) => base44.entities.UserMemory.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['memories'] }),
  });

  // Delete memory
  const deleteMemoryMutation = useMutation({
    mutationFn: (id) => base44.entities.UserMemory.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['memories'] }),
  });

  // Edit memory
  const editMemoryMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UserMemory.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['memories'] }),
  });

  // Load conversation messages when selecting
  useEffect(() => {
    if (activeConvId && conversations.length) {
      const conv = conversations.find((c) => c.id === activeConvId);
      if (conv?.messages) {
        setMessages(conv.messages);
      }
    }
  }, [activeConvId, conversations]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Auto-select first conversation if none in URL
  useEffect(() => {
    if (!activeConvId && conversations.length > 0) {
      navigate(`/chat/${conversations[0].id}`, { replace: true });
    }
  }, [conversations, activeConvId, navigate]);

  const buildMemoryContext = () => {
    if (memories.length === 0) return '';
    const facts = memories.map((m) => `- [${m.category}] ${m.fact}`).join('\n');
    return `\n\nHere is what you remember about the user from previous conversations:\n${facts}\n\nUse this knowledge naturally — don't list it back unless relevant.`;
  };

  const extractTasks = async (text) => {
    const taskRegex = /\|\|\|TASK\|\|\|(.*?)\|\|\|ENDTASK\|\|\|/gs;
    let cleanText = text;
    let match;
    while ((match = taskRegex.exec(text)) !== null) {
      try {
        const parsed = JSON.parse(match[1]);
        await base44.entities.ScheduledTask.create({ ...parsed, created_by_ai: true, status: 'pending' });
      } catch (e) { /* ignore */ }
      cleanText = cleanText.replace(match[0], '');
    }
    return cleanText.trim();
  };

  const extractMemories = (text) => {
    const memoryRegex = /\|\|\|MEMORY\|\|\|(.*?)\|\|\|END\|\|\|/gs;
    const extracted = [];
    let match;
    let cleanText = text;

    while ((match = memoryRegex.exec(text)) !== null) {
      try {
        const parsed = JSON.parse(match[1]);
        extracted.push(parsed);
      } catch (e) {
        // ignore parse errors
      }
      cleanText = cleanText.replace(match[0], '');
    }

    return { cleanText: cleanText.trim(), memories: extracted };
  };

  const RIME_API_KEY = import.meta.env.VITE_RIME_API_KEY;

  // Read file contents for context
  const readFileContents = async (files) => {
    const results = [];
    for (const file of files) {
      const text = await file.text().catch(() => '[unreadable]');
      results.push({ name: file.name, content: text.slice(0, 8000) });
    }
    return results;
  };

  // Extract file generation block from AI response
  const extractGeneratedFile = (text) => {
    const match = text.match(/\|\|\|FILE\|\|\|filename:(.*?)\n([\s\S]*?)\|\|\|ENDFILE\|\|\|/);
    if (!match) return { cleanText: text, file: null };
    const filename = match[1].trim();
    const content = match[2].trim();
    const cleanText = text.replace(match[0], '').trim();
    return { cleanText, file: { filename, content } };
  };

  const speakText = useCallback((text, prefs = voicePrefs) => {
    speakWithRime(text, RIME_API_KEY, {
      onStart: () => setIsSpeaking(true),
      onEnd: () => setIsSpeaking(false),
      speed: prefs.speed,
      pitch: prefs.pitch,
      style: prefs.style,
    });
  }, [RIME_API_KEY, voicePrefs]);

  const handleSend = useCallback(async (text, attachedFiles = []) => {
    // Count total user messages across all conversations
    if (!isSubscribed) {
      const totalUserMessages = conversations.reduce((acc, c) => {
        return acc + (c.messages?.filter((m) => m.role === 'user').length || 0);
      }, 0);
      if (totalUserMessages >= FREE_MESSAGE_LIMIT) {
        setShowPaywall(true);
        return;
      }
    }

    let convId = activeConvId;

    // Create conversation if none exists
    if (!convId) {
      const conv = await base44.entities.Conversation.create({
        title: text.slice(0, 50) + (text.length > 50 ? '...' : ''),
        messages: [],
        message_count: 0,
      });
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      convId = conv.id;
      navigate(`/chat/${convId}`, { replace: false });
    }

    // Read any attached files
    let fileContext = '';
    if (attachedFiles.length > 0) {
      const fileContents = await readFileContents(attachedFiles);
      fileContext = '\n\n--- ATTACHED FILES FOR CONTEXT ---\n' +
        fileContents.map((f) => `[File: ${f.name}]\n${f.content}`).join('\n\n---\n');
    }

    const userMsg = {
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
      attached_files: attachedFiles.map((f) => f.name),
    };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsTyping(true);
    setTypingStatus('searching...');
    setShowSidebar(false);

    const memoryContext = buildMemoryContext();
    const fullPrompt = `${buildSystemPrompt()}${memoryContext}

If the user asks you to write, draft, create, or generate any document, article, essay, report, letter, story, code file, or any written content longer than a paragraph — output it as a downloadable file using this exact format at the END of your response (after your conversational reply):
|||FILE|||filename:suggested-filename.txt
[full file content here]
|||ENDFILE|||
Choose a descriptive filename with the right extension (.txt, .md, .py, .html, etc.).
Only use the file block when the user explicitly wants written content to keep/download.${fileContext}

Conversation so far:
${newMessages
      .map((m) => `${m.role === 'user' ? 'User' : 'PhantomAI'}: ${m.content}`)
      .slice(-10)
      .join('\n')}

Respond as PhantomAI to the user's latest message.`;

    setTypingStatus('retrieving signal...');

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: fullPrompt,
      add_context_from_internet: true,
    });

    const afterTasks = await extractTasks(result);
    const { cleanText: afterFile, file: generatedFile } = extractGeneratedFile(afterTasks);
    const { cleanText, memories: newMemories } = extractMemories(afterFile);

    // Save memories
    for (const mem of newMemories) {
      createMemoryMutation.mutate({
        fact: mem.fact,
        category: mem.category,
        confidence: 0.8,
      });
    }

    const aiMsg = {
      role: 'assistant',
      content: cleanText,
      timestamp: new Date().toISOString(),
      used_web: true,
      ...(generatedFile ? { generated_file: generatedFile } : {}),
    };

    const updatedMessages = [...newMessages, aiMsg];
    setMessages(updatedMessages);
    setIsTyping(false);

    // Speak AI response if in voice mode
    if (voiceMode) speakText(cleanText, voicePrefs);

    // Generate title if first message
    const isFirstMessage = newMessages.filter((m) => m.role === 'user').length === 1;

    updateConvMutation.mutate({
      id: convId,
      data: {
        messages: updatedMessages,
        message_count: updatedMessages.length,
        last_message_preview: cleanText.slice(0, 80),
        ...(isFirstMessage ? { title: text.slice(0, 50) + (text.length > 50 ? '...' : '') } : {}),
      },
    });
  }, [activeConvId, messages, memories, voiceMode, speakText]);

  const handleNewConversation = () => {
    createConvMutation.mutate({
      title: 'New Thread',
      messages: [],
      message_count: 0,
    });
    setShowMemories(false);
  };

  // Pull-to-refresh handlers
  const handleTouchStart = (e) => {
    const container = messagesContainerRef.current;
    if (container && container.scrollTop === 0) {
      touchStartY.current = e.touches[0].clientY;
    } else {
      touchStartY.current = 0;
    }
  };

  const handleTouchMove = (e) => {
    if (!touchStartY.current) return;
    const delta = e.touches[0].clientY - touchStartY.current;
    if (delta > 0) {
      setPullY(Math.min(delta * 0.5, PULL_THRESHOLD));
    }
  };

  const handleTouchEnd = async () => {
    if (pullY >= PULL_THRESHOLD) {
      setIsRefreshing(true);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['conversations'] }),
        queryClient.invalidateQueries({ queryKey: ['memories'] }),
      ]);
      setTimeout(() => setIsRefreshing(false), 600);
    }
    setPullY(0);
    touchStartY.current = 0;
  };

  const showChips = messages.length === 0 && !isTyping;

  return (
    <div className="flex overflow-hidden bg-background grid-bg" style={{ height: '100%' }}>
      <div className="scanline-overlay" />

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-72 transform transition-transform md:relative md:translate-x-0 ${
          showSidebar ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="relative h-full">
          <AnimatePresence>
            {showMemories && (
              <MemoryPanel
                memories={memories}
                onClose={() => setShowMemories(false)}
                onDelete={(id) => deleteMemoryMutation.mutate(id)}
                onEdit={(id, data) => editMemoryMutation.mutate({ id, data })}
              />
            )}
          </AnimatePresence>
          <ConversationList
            conversations={conversations}
            activeId={activeConvId}
            onSelect={(id) => {
              setActiveConvId(id);
              setShowSidebar(false);
              setShowMemories(false);
            }}
            onCreate={handleNewConversation}
            onDelete={(id) => deleteConvMutation.mutate(id)}
            onClose={() => setShowSidebar(false)}
            memoryCount={memories.length}
            onViewMemories={() => setShowMemories(true)}
          />
        </div>
      </div>

      {/* Overlay */}
      {showSidebar && (
        <div
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={() => setShowSidebar(false)}
        />
      )}

      {/* Main Chat */}
      <div className="flex-1 flex flex-col relative min-w-0 overflow-hidden">
        <CornerDecorations />
        <ChatHeader
          onToggleSidebar={() => setShowSidebar(!showSidebar)}
          memoryCount={memories.length}
          hasActiveConversation={!!activeConvId}
          onBack={() => navigate('/', { replace: false })}
        />

        {/* Pull-to-refresh indicator */}
        <div
          className="relative z-10 flex items-center justify-center overflow-hidden transition-all"
          style={{ height: isRefreshing ? 40 : pullY > 0 ? pullY : 0 }}
        >
          <motion.div
            animate={{ rotate: isRefreshing ? 360 : pullY * 3 }}
            transition={isRefreshing ? { repeat: Infinity, duration: 0.7, ease: 'linear' } : { duration: 0 }}
          >
            <RefreshCw className={`w-4 h-4 transition-colors ${pullY >= PULL_THRESHOLD || isRefreshing ? 'text-primary' : 'text-muted-foreground/40'}`} />
          </motion.div>
        </div>

        {/* Messages */}
        <div
          ref={messagesContainerRef}
          className="flex-1 overflow-y-auto px-4 py-4 space-y-4 overscroll-contain"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Welcome message */}
          {messages.length === 0 && (
            <MessageBubble
              message={{
                role: 'assistant',
                content: `Signal acquired. **PhantomAI** is now online — fully encrypted, with live web access and self-learning memory.\n\nI remember everything you tell me across conversations. The more we talk, the better I understand you. Ask me anything, or let me help you plan, learn, or explore.`,
              }}
            />
          )}

          {messages.map((msg, i) => (
            <MessageBubble key={i} message={msg} />
          ))}

          <AnimatePresence>
            {isTyping && <TypingIndicator status={typingStatus} />}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>

        {showChips && !voiceMode && <SuggestionChips onSelect={handleSend} />}

        <ChatInput onSend={handleSend} disabled={isTyping} voiceMode={voiceMode} onToggleVoice={() => {
          if (voiceMode) { stopSpeaking(); setIsSpeaking(false); }
          setVoiceMode(v => !v);
        }} />

        {/* Voice Mode Overlay */}
        <AnimatePresence>
          {voiceMode && (
            <VoiceMode
              onTranscript={handleSend}
              isSpeaking={isSpeaking}
              disabled={isTyping}
              onClose={() => { stopSpeaking(); setIsSpeaking(false); setVoiceMode(false); }}
            />
          )}
        </AnimatePresence>

        <BottomNav activeTab="chat" />
      </div>

      {showPaywall && (
        <PaywallModal
          onClose={() => setShowPaywall(false)}
          onActivated={() => { setIsSubscribed(true); setShowPaywall(false); window.location.reload(); }}
        />
      )}
    </div>
  );
}