import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarClock, Plus, Trash2, Check, X, ChevronDown, ChevronUp } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const PRIORITIES = ['low', 'medium', 'high'];
const priorityColors = {
  low: 'text-emerald-400 border-emerald-400/20 bg-emerald-400/5',
  medium: 'text-amber-400 border-amber-400/20 bg-amber-400/5',
  high: 'text-rose-400 border-rose-400/20 bg-rose-400/5',
};

function TaskForm({ onSave, onCancel }) {
  const [title, setTitle] = useState('');
  const [note, setNote] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState('medium');

  const handleSave = () => {
    if (!title.trim() || !dueDate) return;
    onSave({ title, note, due_date: dueDate, due_time: dueTime, priority, status: 'pending' });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="p-4 rounded-xl bg-[rgba(13,26,46,0.9)] border border-primary/25 space-y-3"
    >
      <input
        autoFocus
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Task or reminder title..."
        className="w-full bg-[rgba(0,0,0,0.3)] border border-border rounded-lg px-3 py-2.5 text-sm text-foreground font-body outline-none focus:border-primary/50 transition-colors placeholder:text-muted-foreground/40"
      />
      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Optional note..."
        rows={2}
        className="w-full bg-[rgba(0,0,0,0.3)] border border-border rounded-lg px-3 py-2 text-sm text-foreground font-body outline-none focus:border-primary/50 transition-colors placeholder:text-muted-foreground/40 resize-none"
      />
      <div className="flex gap-2">
        <input
          type="date"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
          className="flex-1 bg-[rgba(0,0,0,0.3)] border border-border rounded-lg px-3 py-2 text-sm text-foreground font-body outline-none focus:border-primary/50 transition-colors"
        />
        <input
          type="time"
          value={dueTime}
          onChange={(e) => setDueTime(e.target.value)}
          className="w-28 bg-[rgba(0,0,0,0.3)] border border-border rounded-lg px-3 py-2 text-sm text-foreground font-body outline-none focus:border-primary/50 transition-colors"
        />
      </div>
      <div className="flex gap-2">
        {PRIORITIES.map((p) => (
          <button
            key={p}
            onClick={() => setPriority(p)}
            className={`flex-1 py-1.5 rounded-lg border text-[11px] font-body capitalize transition-all select-none ${
              priority === p ? priorityColors[p] : 'border-border text-muted-foreground hover:border-border/80'
            }`}
          >
            {p}
          </button>
        ))}
      </div>
      <div className="flex gap-2 pt-1">
        <button
          onClick={onCancel}
          className="flex-1 py-2.5 rounded-lg bg-secondary/50 border border-border text-sm text-muted-foreground font-body select-none"
        >
          Cancel
        </button>
        <button
          onClick={handleSave}
          disabled={!title.trim() || !dueDate}
          className="flex-1 py-2.5 rounded-lg bg-primary/20 border border-primary/40 text-sm text-primary font-body disabled:opacity-40 select-none"
        >
          Add Task
        </button>
      </div>
    </motion.div>
  );
}

function TaskItem({ task, onDone, onDelete }) {
  const [expanded, setExpanded] = useState(false);
  const isDone = task.status === 'done';

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`rounded-xl border transition-all ${isDone ? 'opacity-50 border-border bg-[rgba(13,26,46,0.4)]' : 'bg-[rgba(13,26,46,0.7)] border-[rgba(100,200,255,0.1)] hover:border-primary/20'}`}
    >
      <div className="flex items-center gap-3 px-4 py-3">
        <button
          onClick={() => onDone(task.id, isDone ? 'pending' : 'done')}
          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all select-none ${isDone ? 'bg-emerald-500/30 border-emerald-500' : 'border-border hover:border-primary/50'}`}
        >
          {isDone && <Check className="w-3 h-3 text-emerald-400" />}
        </button>
        <div className="flex-1 min-w-0">
          <p className={`text-[13px] font-body ${isDone ? 'line-through text-muted-foreground' : 'text-foreground'}`}>{task.title}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-[10px] text-muted-foreground">{task.due_date}{task.due_time ? ` · ${task.due_time}` : ''}</span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${priorityColors[task.priority]}`}>{task.priority}</span>
            {task.created_by_ai && <span className="text-[10px] text-accent/60">AI</span>}
          </div>
        </div>
        <div className="flex items-center gap-1">
          {task.note && (
            <button onClick={() => setExpanded(!expanded)} className="p-1.5 rounded-lg hover:bg-secondary transition-colors select-none">
              {expanded ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />}
            </button>
          )}
          <button onClick={() => onDelete(task.id)} className="p-1.5 rounded-lg hover:bg-destructive/20 transition-colors select-none">
            <Trash2 className="w-3.5 h-3.5 text-destructive/50 hover:text-destructive/80" />
          </button>
        </div>
      </div>
      {expanded && task.note && (
        <div className="px-4 pb-3">
          <p className="text-[12px] text-muted-foreground leading-relaxed">{task.note}</p>
        </div>
      )}
    </motion.div>
  );
}

export default function Tasks() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState('pending');

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.ScheduledTask.list('-due_date', 100),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ScheduledTask.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['tasks'] }); setShowForm(false); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.ScheduledTask.update(id, { status }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tasks'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ScheduledTask.delete(id),
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['tasks'] });
      const prev = queryClient.getQueryData(['tasks']);
      queryClient.setQueryData(['tasks'], (old) => old?.filter((t) => t.id !== id) ?? []);
      return { prev };
    },
    onError: (_e, _id, ctx) => queryClient.setQueryData(['tasks'], ctx.prev),
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['tasks'] }),
  });

  const filtered = tasks.filter((t) => filter === 'all' || t.status === filter);
  const pendingCount = tasks.filter((t) => t.status === 'pending').length;

  return (
    <div className="flex flex-col bg-background grid-bg" style={{ height: '100%' }}>
      <div className="scanline-overlay" />

      {/* Header */}
      <div className="relative z-10 flex items-center gap-3 px-4 py-4 border-b border-[rgba(100,200,255,0.12)] bg-[rgba(6,8,16,0.85)]">
        <div className="w-8 h-8 rounded-full bg-[#0d1a2e] border border-primary/40 flex items-center justify-center flex-shrink-0">
          <CalendarClock className="w-4 h-4 text-primary/80" />
        </div>
        <h1 className="font-heading text-base font-bold tracking-[0.12em] text-[#c8e6ff]">TASKS</h1>
        {pendingCount > 0 && (
          <span className="ml-1 bg-primary/15 border border-primary/25 rounded-full px-2 py-0.5 text-[10px] text-primary">{pendingCount} pending</span>
        )}
        <button
          onClick={() => setShowForm(true)}
          className="ml-auto flex items-center gap-1.5 bg-primary/10 border border-primary/30 rounded-lg px-3 py-1.5 text-[12px] text-primary hover:bg-primary/20 transition-all select-none"
        >
          <Plus className="w-3.5 h-3.5" />
          New
        </button>
      </div>

      {/* Filter tabs */}
      <div className="relative z-10 flex gap-1 px-4 py-2 border-b border-[rgba(100,200,255,0.08)] bg-[rgba(6,8,16,0.6)]">
        {['pending', 'done', 'all'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`flex-1 py-1.5 rounded-lg text-[11px] font-body capitalize transition-all select-none ${filter === f ? 'bg-primary/15 border border-primary/30 text-primary' : 'text-muted-foreground hover:text-foreground'}`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="relative z-10 flex-1 overflow-y-auto p-4 space-y-2 pb-24">
        <AnimatePresence>
          {showForm && (
            <TaskForm
              onSave={(data) => createMutation.mutate(data)}
              onCancel={() => setShowForm(false)}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {filtered.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onDone={(id, status) => updateMutation.mutate({ id, status })}
              onDelete={(id) => deleteMutation.mutate(id)}
            />
          ))}
        </AnimatePresence>

        {filtered.length === 0 && !showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20 space-y-3">
            <CalendarClock className="w-12 h-12 mx-auto text-primary/20" />
            <p className="text-sm text-muted-foreground">No {filter === 'all' ? '' : filter} tasks yet.</p>
            <p className="text-[11px] text-muted-foreground/60">PhantomAI can schedule tasks for you, or add one manually.</p>
          </motion.div>
        )}
      </div>

      <BottomNav activeTab="tasks" />
    </div>
  );
}