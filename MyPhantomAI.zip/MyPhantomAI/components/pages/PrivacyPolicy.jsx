import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Shield } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const PRIVACY_CONTENT = `# PRIVACY POLICY

**Last updated May 07, 2026**

This Privacy Notice for Phantom Studios ("**we**," "**us**," or "**our**"), describes how and why we might access, collect, store, use, and/or share ("**process**") your personal information when you use our services ("**Services**"), including when you:

- Download and use our mobile application (MyPhantomAI), or any other application of ours that links to this Privacy Notice
- Use MyPhantomAI — an intuitive, self-learning digital companion designed to adapt to your unique preferences, streamline your daily tasks, and evolve alongside your personal goals.
- Engage with us in other related ways, including any marketing or events

**Questions or concerns?** Reading this Privacy Notice will help you understand your privacy rights and choices. If you do not agree with our policies and practices, please do not use our Services. If you still have any questions or concerns, please contact us at [contact.phantom.studios@gmail.com](mailto:contact.phantom.studios@gmail.com).

---

## SUMMARY OF KEY POINTS

**What personal information do we process?** When you visit, use, or navigate our Services, we may process personal information depending on how you interact with us and the Services, the choices you make, and the products and features you use.

**Do we process any sensitive personal information?** We do not process sensitive personal information.

**Do we collect any information from third parties?** We do not collect any information from third parties.

**How do we process your information?** We process your information to provide, improve, and administer our Services, communicate with you, for security and fraud prevention, and to comply with law.

**How do we keep your information safe?** We have adequate organizational and technical processes and procedures in place to protect your personal information. However, no electronic transmission over the internet or information storage technology can be guaranteed to be 100% secure.

**What are your rights?** Depending on where you are located geographically, the applicable privacy law may mean you have certain rights regarding your personal information.

**How do you exercise your rights?** The easiest way to exercise your rights is by contacting us at [contact.phantom.studios@gmail.com](mailto:contact.phantom.studios@gmail.com) or submitting a [data subject access request](https://app.termly.io/dsar/8c570457-893f-4d29-871f-8aab981a98ca).

---

## TABLE OF CONTENTS

1. WHAT INFORMATION DO WE COLLECT?
2. HOW DO WE PROCESS YOUR INFORMATION?
3. WHAT LEGAL BASES DO WE RELY ON TO PROCESS YOUR PERSONAL INFORMATION?
4. WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?
5. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?
6. DO WE OFFER ARTIFICIAL INTELLIGENCE-BASED PRODUCTS?
7. HOW DO WE HANDLE YOUR SOCIAL LOGINS?
8. HOW LONG DO WE KEEP YOUR INFORMATION?
9. HOW DO WE KEEP YOUR INFORMATION SAFE?
10. WHAT ARE YOUR PRIVACY RIGHTS?
11. CONTROLS FOR DO-NOT-TRACK FEATURES
12. DO UNITED STATES RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?
13. DO OTHER REGIONS HAVE SPECIFIC PRIVACY RIGHTS?
14. DO WE MAKE UPDATES TO THIS NOTICE?
15. HOW CAN YOU CONTACT US ABOUT THIS NOTICE?
16. HOW CAN YOU REVIEW, UPDATE, OR DELETE THE DATA WE COLLECT FROM YOU?

---

## 1. WHAT INFORMATION DO WE COLLECT?

### Personal information you disclose to us

*In Short: We collect personal information that you provide to us.*

We collect personal information that you voluntarily provide to us when you register on the Services, express an interest in obtaining information about us or our products and Services, when you participate in activities on the Services, or otherwise when you contact us.

**Personal Information Provided by You.** The personal information we collect may include:

- Names
- Email addresses
- Phone numbers
- Mailing addresses
- Job titles
- Usernames
- Passwords
- Contact preferences
- Contact or authentication data
- Billing addresses
- Debit/credit card numbers

**Sensitive Information.** We do not process sensitive information.

**Social Media Login Data.** We may provide you with the option to register with us using your existing social media account details.

All personal information that you provide to us must be true, complete, and accurate, and you must notify us of any changes to such personal information.

### Google API

Our use of information received from Google APIs will adhere to [Google API Services User Data Policy](https://developers.google.com/terms/api-services-user-data-policy), including the Limited Use requirements.

---

## 2. HOW DO WE PROCESS YOUR INFORMATION?

*In Short: We process your information to provide, improve, and administer our Services, communicate with you, for security and fraud prevention, and to comply with law.*

**We process your personal information for the following purposes:**

- **To facilitate account creation and authentication and otherwise manage user accounts.**
- **To save or protect an individual's vital interest.** We may process your information when necessary to save or protect an individual's vital interest, such as to prevent harm.

---

## 3. WHAT LEGAL BASES DO WE RELY ON TO PROCESS YOUR INFORMATION?

*In Short: We only process your personal information when we believe it is necessary and we have a valid legal reason to do so under applicable law.*

If you are located in the EU or UK, the GDPR and UK GDPR require us to explain the valid legal bases we rely on. We may process your information if you have given us permission (consent), or based on legitimate interests, legal obligations, or vital interests.

If you are located in Canada, we may process your information if you have given us express or implied permission to use it for a specific purpose, or in limited circumstances where required by law.

---

## 4. WHEN AND WITH WHOM DO WE SHARE YOUR PERSONAL INFORMATION?

*In Short: We may share information in specific situations and with specific third parties.*

- **Business Transfers.** We may share or transfer your information in connection with any merger, sale of company assets, financing, or acquisition of all or a portion of our business.

---

## 5. DO WE USE COOKIES AND OTHER TRACKING TECHNOLOGIES?

*In Short: We may use cookies and other tracking technologies to collect and store your information.*

We may use cookies and similar tracking technologies (like web beacons and pixels) to gather information when you interact with our Services. Some tracking technologies help us maintain the security of our Services and your account, prevent crashes, fix bugs, save your preferences, and assist with basic site functions.

---

## 6. DO WE OFFER ARTIFICIAL INTELLIGENCE-BASED PRODUCTS?

*In Short: We offer products, features, or tools powered by artificial intelligence, machine learning, or similar technologies.*

As part of our Services, we offer products, features, or tools powered by artificial intelligence, machine learning, or similar technologies (collectively, "AI Products"). These tools are designed to enhance your experience and provide innovative solutions.

**Our AI Products are designed for:**
- AI bots
- AI companion
- Natural language processing

**How We Process Your Data Using AI.** All personal information processed using our AI Products is handled in accordance with our Privacy Notice and our agreement with third parties. This ensures high security and safeguards your personal information throughout the process.

---

## 7. HOW DO WE HANDLE YOUR SOCIAL LOGINS?

*In Short: If you choose to register or log in using a social media account, we may have access to certain information about you.*

Where you choose to register using a social media account, we will receive certain profile information from your social media provider. We will use the information only for the purposes described in this Privacy Notice.

---

## 8. HOW LONG DO WE KEEP YOUR INFORMATION?

*In Short: We keep your information for as long as necessary to fulfill the purposes outlined in this Privacy Notice unless otherwise required by law.*

When we have no ongoing legitimate business need to process your personal information, we will either delete or anonymize such information.

---

## 9. HOW DO WE KEEP YOUR INFORMATION SAFE?

*In Short: We aim to protect your personal information through a system of organizational and technical security measures.*

We have implemented appropriate and reasonable technical and organizational security measures designed to protect the security of any personal information we process. Despite our safeguards, no electronic transmission over the Internet can be guaranteed to be 100% secure.

---

## 10. WHAT ARE YOUR PRIVACY RIGHTS?

*In Short: Depending on your location, you have rights that allow you greater access to and control over your personal information.*

In some regions (like the EEA, UK, Switzerland, and Canada), you have certain rights under applicable data protection laws. These may include the right to:

- Request access and obtain a copy of your personal information
- Request rectification or erasure
- Restrict the processing of your personal information
- Data portability (if applicable)
- Not be subject to automated decision-making

To exercise your rights, please contact us at [contact.phantom.studios@gmail.com](mailto:contact.phantom.studios@gmail.com).

**Account Information.** If you would like to review or change the information in your account or terminate your account, you can contact us using the contact information provided.

---

## 11. CONTROLS FOR DO-NOT-TRACK FEATURES

Most web browsers and some mobile operating systems include a Do-Not-Track ("DNT") feature. At this stage, no uniform technology standard for recognizing and implementing DNT signals has been finalized. As such, we do not currently respond to DNT browser signals.

---

## 12. DO UNITED STATES RESIDENTS HAVE SPECIFIC PRIVACY RIGHTS?

*In Short: If you are a resident of certain US states, you may have specific rights regarding access to your personal information.*

**Categories of personal information we collect:**

- Identifiers (name, alias, email address, account name)
- Commercial information (transaction data, purchase history)
- Internet or other electronic network activity (browsing history, interactions with our Services)
- Geolocation data
- Inferences drawn from any of the above information

**Your Rights.** You may have the right to: know what personal information we collect, request deletion, opt out of sale or sharing, and not be discriminated against for exercising your rights.

---

## 13. DO OTHER REGIONS HAVE SPECIFIC PRIVACY RIGHTS?

**Australia and New Zealand.** We collect and process your personal information under the obligations and conditions set by Australia's Privacy Act 1988 and New Zealand's Privacy Act 2020.

**Republic of South Africa.** At any time, you have the right to request access to or correction of your personal information.

---

## 14. DO WE MAKE UPDATES TO THIS NOTICE?

*In Short: Yes, we will update this notice as necessary to stay compliant with relevant laws.*

We may update this Privacy Notice from time to time. The updated version will be indicated by an updated "Last updated" date at the top of this Privacy Notice.

---

## 15. HOW CAN YOU CONTACT US ABOUT THIS NOTICE?

If you have questions or comments about this notice, you may contact us at:

**Phantom Studios**  
Email: [contact.phantom.studios@gmail.com](mailto:contact.phantom.studios@gmail.com)

---

## 16. HOW CAN YOU REVIEW, UPDATE, OR DELETE THE DATA WE COLLECT FROM YOU?

Based on the applicable laws of your country or state of residence, you may have the right to request access to the personal information we collect from you, correct inaccuracies, or delete your personal information.

To submit a request, please contact us at [contact.phantom.studios@gmail.com](mailto:contact.phantom.studios@gmail.com) or submit a [data subject access request](https://app.termly.io/dsar/8c570457-893f-4d29-871f-8aab981a98ca).
`;

export default function PrivacyPolicy() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col h-full bg-background grid-bg overflow-hidden">
      <div className="scanline-overlay" />
      <div className="relative z-10 flex items-center gap-3 px-4 py-3 border-b border-[rgba(100,200,255,0.12)] bg-[rgba(6,8,16,0.85)] flex-shrink-0">
        <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-secondary transition-colors">
          <ChevronLeft className="w-4 h-4 text-primary" />
        </button>
        <Shield className="w-4 h-4 text-primary" />
        <h1 className="font-heading text-sm font-bold tracking-[0.12em] text-[#c8e6ff]">PRIVACY POLICY</h1>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-6 relative z-10">
        <div className="max-w-2xl mx-auto">
          <div className="rounded-xl bg-[rgba(13,26,46,0.7)] border border-[rgba(100,200,255,0.1)] p-6">
            <ReactMarkdown
              className="prose prose-sm prose-invert max-w-none text-[#c8d8f0]"
              components={{
                h1: ({ children }) => <h1 className="font-heading text-xl font-bold tracking-[0.1em] text-[#c8e6ff] mb-2">{children}</h1>,
                h2: ({ children }) => <h2 className="font-heading text-sm font-bold tracking-[0.08em] text-primary mt-8 mb-3 pb-2 border-b border-[rgba(100,200,255,0.1)]">{children}</h2>,
                h3: ({ children }) => <h3 className="font-body text-sm font-bold text-[#c8e6ff] mt-4 mb-2">{children}</h3>,
                p: ({ children }) => <p className="text-[13px] text-[#a0b8d0] leading-relaxed my-2">{children}</p>,
                ul: ({ children }) => <ul className="my-2 ml-4 space-y-1">{children}</ul>,
                li: ({ children }) => <li className="text-[13px] text-[#a0b8d0] leading-relaxed list-disc">{children}</li>,
                strong: ({ children }) => <strong className="text-[#c8e6ff] font-bold">{children}</strong>,
                em: ({ children }) => <em className="text-muted-foreground italic">{children}</em>,
                a: ({ children, href }) => <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{children}</a>,
                hr: () => <hr className="border-[rgba(100,200,255,0.1)] my-6" />,
                ol: ({ children }) => <ol className="my-2 ml-4 space-y-1 list-decimal">{children}</ol>,
              }}
            >
              {PRIVACY_CONTENT}
            </ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
}