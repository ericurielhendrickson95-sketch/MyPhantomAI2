import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Zap, ChevronRight, Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const PLANS = [
  { label: 'Monthly', price: '$35', period: '/month', link: 'https://buy.stripe.com/8x214n4SY9SggpsdOfabK03' },
  { label: 'Yearly', price: '$299', period: '/year', badge: 'Save 29%', link: 'https://buy.stripe.com/eVqaEX1GMe8wa1425xabK04' },
];

export default function PaywallModal({ onClose, onActivated }) {
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState('');
  const [selectedPlan, setSelectedPlan] = useState(0);

  const handleVerify = async () => {
    setVerifying(true);
    setError('');
    try {
      await base44.auth.updateMe({ is_subscribed: true, subscribed_at: new Date().toISOString() });
      onActivated?.();
    } catch (e) {
      setError('Could not verify subscription. Please make sure you are logged in.');
    } finally {
      setVerifying(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 25 }}
          className="w-full max-w-sm rounded-2xl bg-[rgba(8,14,28,0.97)] border border-[rgba(100,200,255,0.2)] p-6 relative"
          style={{ boxShadow: '0 0 40px rgba(100,200,255,0.08)' }}
        >
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-secondary transition-colors text-muted-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          {/* Icon */}
          <div className="flex justify-center mb-4">
            <div
              className="w-14 h-14 rounded-full bg-[#0d1a2e] border-2 border-primary/50 flex items-center justify-center"
              style={{ animation: 'orb-pulse 3s ease-in-out infinite' }}
            >
              <Lock className="w-6 h-6 text-primary" />
            </div>
          </div>

          <h2 className="font-heading text-lg font-bold tracking-[0.1em] text-[#c8e6ff] text-center mb-1">
            FREE LIMIT REACHED
          </h2>
          <p className="text-muted-foreground text-xs text-center mb-1">
            You've used your free messages.
          </p>
          {/* Plan toggle */}
          <div className="flex gap-2 mb-5">
            {PLANS.map((plan, i) => (
              <button
                key={plan.label}
                onClick={() => setSelectedPlan(i)}
                className={`flex-1 relative flex flex-col items-center py-2.5 px-3 rounded-xl border transition-all text-xs ${
                  selectedPlan === i
                    ? 'bg-primary/10 border-primary/50 text-primary'
                    : 'bg-secondary/40 border-border text-muted-foreground hover:border-primary/25'
                }`}
              >
                {plan.badge && (
                  <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-emerald-500 text-black text-[9px] font-bold px-1.5 py-0.5 rounded-full whitespace-nowrap">
                    {plan.badge}
                  </span>
                )}
                <span className="font-heading font-bold text-sm">{plan.price}</span>
                <span className="text-[10px] opacity-70">{plan.period}</span>
                <span className="text-[10px] mt-0.5 font-medium">{plan.label}</span>
              </button>
            ))}
          </div>

          <ul className="space-y-2 mb-6 text-[12px] text-muted-foreground">
            {['Unlimited conversations', 'Persistent self-learning memory', 'Live web access', 'End-to-end encrypted'].map((f) => (
              <li key={f} className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>

          {/* Steps */}
          <div className="space-y-2 mb-4">
            <a
              href={PLANS[selectedPlan].link}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-3 rounded-xl bg-primary/10 border border-primary/30 text-sm text-primary hover:bg-primary/20 transition-all font-body w-full"
            >
              <span className="w-5 h-5 rounded-full bg-primary/20 border border-primary/30 text-[10px] font-bold text-primary flex items-center justify-center flex-shrink-0">1</span>
              Subscribe — {PLANS[selectedPlan].price}{PLANS[selectedPlan].period}
              <ChevronRight className="w-4 h-4 text-primary/50 ml-auto" />
            </a>

            <button
              onClick={handleVerify}
              disabled={verifying}
              className="flex items-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-sm hover:bg-emerald-500/20 transition-all font-body disabled:opacity-50 w-full"
            >
              {verifying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-[10px] font-bold text-emerald-400 flex items-center justify-center flex-shrink-0">2</span>
              I've subscribed — Activate Access
            </button>
          </div>

          {error && <p className="text-xs text-destructive text-center">{error}</p>}
          <p className="text-[10px] text-muted-foreground text-center mt-3">Subscribe then click Activate to unlock full access.</p>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}