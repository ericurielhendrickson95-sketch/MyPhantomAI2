import React from 'react';

export default function CornerDecorations() {
  return (
    <>
      <div className="absolute top-2 left-2 w-4 h-4 border-t-[1.5px] border-l-[1.5px] border-primary/30 z-5 pointer-events-none" />
      <div className="absolute bottom-2 right-2 w-4 h-4 border-b-[1.5px] border-r-[1.5px] border-primary/30 z-5 pointer-events-none" />
    </>
  );
}