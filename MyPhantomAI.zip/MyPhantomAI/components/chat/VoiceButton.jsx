import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff } from 'lucide-react';
import { motion } from 'framer-motion';

export default function VoiceButton({ onTranscript, disabled }) {
  const [isListening, setIsListening] = useState(false);
  const [supported, setSupported] = useState(false);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      setSupported(true);
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onresult = (e) => {
        const transcript = e.results[0][0].transcript.trim();
        if (transcript) onTranscript(transcript);
      };

      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognitionRef.current = recognition;
    }
  }, [onTranscript]);

  const handlePressStart = (e) => {
    e.preventDefault();
    if (!supported || disabled || !recognitionRef.current) return;
    recognitionRef.current.start();
    setIsListening(true);
  };

  const handlePressEnd = (e) => {
    e.preventDefault();
    if (!isListening || !recognitionRef.current) return;
    recognitionRef.current.stop();
    setIsListening(false);
  };

  if (!supported) return null;

  return (
    <motion.button
      whileTap={{ scale: 0.92 }}
      onMouseDown={handlePressStart}
      onMouseUp={handlePressEnd}
      onMouseLeave={handlePressEnd}
      onTouchStart={handlePressStart}
      onTouchEnd={handlePressEnd}
      disabled={disabled}
      className={`relative w-10 h-10 rounded-lg border flex items-center justify-center flex-shrink-0 transition-all disabled:opacity-50 select-none ${
        isListening
          ? 'bg-rose-500/20 border-rose-500/60 text-rose-400'
          : 'bg-primary/10 border-primary/30 text-primary/80 hover:bg-primary/20 hover:border-primary/60'
      }`}
      style={{ userSelect: 'none', WebkitTapHighlightColor: 'transparent' }}
      title="Hold to speak"
    >
      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
      {isListening && (
        <span className="absolute inset-0 rounded-lg animate-ping bg-rose-500/20 pointer-events-none" />
      )}
    </motion.button>
  );
}