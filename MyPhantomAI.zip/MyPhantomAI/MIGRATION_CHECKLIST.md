# Migration Checklist

Convert your existing web app to the monorepo structure and migrate to React Native.

## Phase 1: Organize Web App (Optional)

If you want to move your existing web app to a `web/` folder:

```bash
# From project root
mkdir web
mv components web/
mv src web/
mv lib web/
mv pages web/
mv entities web/
mv index.html web/
mv jsconfig.json web/
mv tailwind.config.js web/
mv postcss.config.js web/
mv vite.config.js web/
mv package.json web/
mv package-lock.json web/
mv README.md web/
```

Then update [root-package.json](root-package.json) to include web app.

## Phase 2: Extract Shared Code

Move these to `shared/lib/`:

- [ ] Authentication logic → `shared/lib/context/AuthContext.tsx`
- [ ] API client → `shared/lib/utils/api.ts`
- [ ] Custom hooks → `shared/lib/hooks/`
- [ ] Type definitions → `shared/lib/types/index.ts`
- [ ] Utility functions → `shared/lib/utils/`
- [ ] Constants → `shared/lib/utils/constants.ts`

## Phase 3: Adapt Web Components for Mobile

### High Priority
- [ ] Chat message component
- [ ] Input component
- [ ] Avatar component
- [ ] Button component
- [ ] Card component

### Medium Priority
- [ ] Voice button → Voice recorder module
- [ ] Theme switcher
- [ ] Modal/Dialog → Alert
- [ ] Sidebar → Drawer

### Low Priority
- [ ] Animations (may need adjustment)
- [ ] Complex forms
- [ ] Charts/visualizations

## Phase 4: Mobile-Specific Features

- [ ] Implement `expo-secure-store` for secure storage
- [ ] Add `expo-camera` for image capture
- [ ] Add `expo-av` for voice recording
- [ ] Implement `expo-notifications` for push notifications
- [ ] Add `expo-sharing` for file sharing
- [ ] Configure deep linking with `expo-linking`

## Phase 5: Testing

- [ ] Test on iOS simulator
- [ ] Test on Android emulator
- [ ] Test shared authentication
- [ ] Test API integration
- [ ] Performance testing

## Phase 6: Deployment Setup

### iOS
- [ ] Create Apple Developer account
- [ ] Set up provisioning profiles
- [ ] Configure app signing
- [ ] Test TestFlight deployment

### Android
- [ ] Create Google Play Developer account
- [ ] Set up keystore and signing config
- [ ] Configure Google Play signing
- [ ] Test internal testing track

## Code Sharing Strategy

### What to Share
```
✅ Business logic
✅ API utilities  
✅ Authentication
✅ Data types
✅ Constants
✅ Validation logic
```

### What NOT to Share
```
❌ UI Components (too different)
❌ Styling (CSS vs StyleSheet)
❌ Navigation (web routes vs RN navigation)
❌ Platform-specific APIs
```

## Environment Setup

### Web (.env)
```
VITE_API_URL=http://localhost:3000
VITE_STRIPE_KEY=pk_test_...
```

### Mobile (.env)
```
EXPO_PUBLIC_API_URL=http://localhost:3000
EXPO_PUBLIC_ENV=development
```

## Common Issues & Solutions

### Import Path Issues
- Use absolute imports in shared library
- Update tsconfig.json paths for each app
- Verify package.json exports field

### Styling Conflicts
- Web: CSS/Tailwind
- Mobile: React Native StyleSheet
- Don't mix them

### State Management
- Use React Query for server state
- Use Context/Zustand for UI state
- Avoid coupling to UI framework

### Navigation
- Web: React Router or custom routing
- Mobile: Expo Router (file-based)
- Share route constants in shared lib

## Progress Tracking

- [ ] Phase 1: Web app organized
- [ ] Phase 2: Shared code extracted
- [ ] Phase 3: Mobile components created
- [ ] Phase 4: Mobile features implemented
- [ ] Phase 5: Testing complete
- [ ] Phase 6: Ready for deployment

## Resources

- [React Native Migration Guide](https://reactnative.dev/docs/react-native-web)
- [Expo SDK Modules](https://docs.expo.dev/sdk/app/)
- [Shared Code Patterns](https://monorepo.tools/)

---

Start with Phase 1 if you haven't already organized your web app into the `web/` folder.
