# MyPhantom AI - Mobile App

React Native/Expo mobile application for MyPhantom AI Chat

## Getting Started

### Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- iOS: Xcode (for iOS development)
- Android: Android Studio (for Android development)

### Installation

```bash
# Install dependencies from root
npm install

# Install mobile dependencies specifically
npm install -w mobile
```

### Development

```bash
# Start Expo development server
npm run dev:mobile

# For iOS
npm run dev:ios

# For Android
npm run dev:android
```

### Building

```bash
# Build for iOS
npm run build:ios

# Build for Android
npm run build:android
```

## Project Structure

```
mobile/
├── app/                    # Expo Router app directory
│   ├── (tabs)/            # Tab-based navigation
│   │   ├── index.tsx      # Chat screen
│   │   ├── memories.tsx   # Memories screen
│   │   └── settings.tsx   # Settings screen
│   └── _layout.tsx        # Root layout
├── assets/                # App icons and images
├── package.json
└── tsconfig.json
```

## Shared Code

This app shares code from `@myphantom/shared`:
- Hooks (`useAuth`, etc.)
- Utilities (API calls, storage)
- Types (User, Message, Conversation)
- Context providers

See [../shared/README.md](../shared/README.md) for details.
