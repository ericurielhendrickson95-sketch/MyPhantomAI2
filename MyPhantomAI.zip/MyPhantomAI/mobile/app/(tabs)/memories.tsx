import { StyleSheet, View, Text, ScrollView } from 'react-native';

export default function MemoriesScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Memories</Text>
      
      <ScrollView style={styles.content}>
        <Text style={styles.subtitle}>Your saved memories and notes will appear here.</Text>
        {/* Memories list will be rendered here */}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    padding: 16,
    paddingTop: 40,
  },
  content: {
    paddingHorizontal: 16,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
});
